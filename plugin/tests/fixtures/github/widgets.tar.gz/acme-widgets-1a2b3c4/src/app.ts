import { formatName } from './util/format'

export class Widget {
  constructor(readonly name: string) {}

  render(): string {
    return formatName(this.name)
  }
}

export function makeWidget(name: string): Widget {
  return new Widget(name)
}
