export const formatName = (name: string) => name.trim().toUpperCase()

export interface Formatter {
  format(value: string): string
}
