package main

func Render(w *Widget) string {
	return w.Name
}
