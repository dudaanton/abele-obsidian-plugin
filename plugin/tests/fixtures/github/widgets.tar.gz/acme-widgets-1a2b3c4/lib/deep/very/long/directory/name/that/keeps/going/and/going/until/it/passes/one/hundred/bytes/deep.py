def format_name(name):
    return name.upper()


class Deep:
    pass
