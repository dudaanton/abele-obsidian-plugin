# Widgets

A widget renders its name.
